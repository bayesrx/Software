#'Spearman Correlation
#'helper distance function
#'
spear=function(matrix){
  cor(matrix,method="spearman")
}